import * as actionType from './actionType';

export const addUser=()=>({
	console.log(data);
	type:actionType.ADD_USER,
	data
});

export const updateUser=()=>({
	type:actionType.UPDATE_USER,
	data
});

export const deleteUser=()=>({
	type:actionType.DELETE_USER,
	data
});