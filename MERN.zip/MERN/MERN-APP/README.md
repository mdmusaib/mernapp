"# Reactjs-Mern-App" 
installation steps:


clone it from github =>git clone https://github.com/mdmusaib/Reactjs-Mern-App.git

npm install && cd client && npm install

exit //because it will not update from cmd so exit and start it will work fine


cd Reactjs-Mern-App

npm start
